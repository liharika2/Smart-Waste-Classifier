class WasteClassifier {

    public Waste classify(String fileName) {
        fileName = fileName.toLowerCase();

        if (fileName.contains("plastic")) {
            return new PlasticWaste();
        } else if (fileName.contains("organic")) {
            return new OrganicWaste();
        } else if (fileName.contains("metal")) {
            return new MetalWaste();
        } else {
            return null;
        }
    }
}