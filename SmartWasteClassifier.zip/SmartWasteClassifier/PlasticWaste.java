class PlasticWaste extends Waste {
    public PlasticWaste() {
        super("Plastic");
    }

    public String getDisposalMethod() {
        return "Recycle ♻️";
    }
}