class OrganicWaste extends Waste {
    public OrganicWaste() {
        super("Organic");
    }

    public String getDisposalMethod() {
        return "Compost 🌱";
    }
}