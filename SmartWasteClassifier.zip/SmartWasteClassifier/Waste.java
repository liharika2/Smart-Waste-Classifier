abstract class Waste {
    protected String type;

    public Waste(String type) {
        this.type = type;
    }

    public abstract String getDisposalMethod();

    public String getType() {
        return type;
    }
}