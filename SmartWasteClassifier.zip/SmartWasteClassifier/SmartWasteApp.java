import javax.swing.*;
import java.awt.*;
import java.io.File;

public class SmartWasteApp extends JFrame {

    JLabel imageLabel, resultLabel;
    WasteClassifier classifier = new WasteClassifier();

    public SmartWasteApp() {
        setTitle("Smart Waste Classifier (OOP)");
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        setLayout(new BorderLayout());

        // 🔝 TITLE
        JLabel title = new JLabel("Smart Waste Classifier", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        // 🟡 IMAGE AREA
        imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(JLabel.CENTER);

        // 🔥 FIX: set size + border
        imageLabel.setPreferredSize(new Dimension(300, 300));
        imageLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        add(imageLabel, BorderLayout.CENTER);

        // 🔻 BOTTOM PANEL
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout());

        JButton uploadBtn = new JButton("Upload Image");
        resultLabel = new JLabel("Result: ");
        resultLabel.setFont(new Font("Arial", Font.BOLD, 14));

        uploadBtn.addActionListener(e -> uploadImage());

        bottomPanel.add(uploadBtn);
        bottomPanel.add(resultLabel);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void uploadImage() {
        JFileChooser chooser = new JFileChooser();
        int res = chooser.showOpenDialog(this);

        if (res == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();

            // Load and scale image
            ImageIcon icon = new ImageIcon(file.getAbsolutePath());
            Image img = icon.getImage().getScaledInstance(300, 300, Image.SCALE_SMOOTH);

            // Set image
            imageLabel.setIcon(new ImageIcon(img));

            // 🔥 FORCE REFRESH (IMPORTANT)
            imageLabel.revalidate();
            imageLabel.repaint();

            // Classification
            Waste waste = classifier.classify(file.getName());

            if (waste != null) {
                resultLabel.setText(
                        "Type: " + waste.getType() +
                        " → " + waste.getDisposalMethod()
                );
            } else {
                resultLabel.setText("Unknown Waste");
            }
        }
    }

    public static void main(String[] args) {
        new SmartWasteApp().setVisible(true);
    }
}