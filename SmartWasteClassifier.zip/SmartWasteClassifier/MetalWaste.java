class MetalWaste extends Waste {
    public MetalWaste() {
        super("Metal");
    }

    public String getDisposalMethod() {
        return "Scrap/Recycling ♻️";
    }
}